package com.example.demo1012;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Demo1012ApplicationTests {

	@Test
	void contextLoads() {
	}

}
