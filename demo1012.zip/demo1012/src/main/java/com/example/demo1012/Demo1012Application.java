package com.example.demo1012;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Demo1012Application {

	public static void main(String[] args) {
		SpringApplication.run(Demo1012Application.class, args);
	}

}
